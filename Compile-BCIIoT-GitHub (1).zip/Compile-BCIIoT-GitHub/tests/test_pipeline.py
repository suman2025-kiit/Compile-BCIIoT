from compile_bciiot.compiler import compile_source
from compile_bciiot.verkle import VerkleCommitment
from compile_bciiot.blockchain import PermissionedBlockchain


def test_full_compilation_pipeline():
    source = "task temp_monitor cpu=2 mem=128 sec=4;"
    result = compile_source(source)
    assert result["tokens"]
    assert result["ast"][0]["name"] == "temp_monitor"
    assert result["executable"][0]["task"] == "temp_monitor"


def test_verkle_root_and_blockchain():
    artifacts = {"a": "token", "b": "ast"}
    commitment = VerkleCommitment(artifacts)
    root = commitment.get_root()

    chain = PermissionedBlockchain()
    chain.append_block([{"verkle_root": root}])

    assert chain.get_latest_verkle_root() == root
    assert chain.verify_chain()
